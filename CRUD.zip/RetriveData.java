package net.codejava;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class RetriveData {
	
	public static void main(String[] args) {
		String dbURL = "jdbc:mysql://localhost:3306/employeedetails";
		String username = "root";
		String password = "root";
		 
		try(Connection conn = DriverManager.getConnection(dbURL, username, password)) {
		 
			String sql = "SELECT * FROM employee_table";
			 
			Statement statement = conn.createStatement();
			ResultSet result = statement.executeQuery(sql);
			 
			int count = 0;
			 
			while (result.next()){
			    String empid = result.getString(1);
			    String empname= result.getString(2);
			    String empadd = result.getString("empadd");
			    
			 
			    String output = "User #%d: %s - %s - %s ";
			    System.out.println(String.format(output, ++count,empid,empname,empadd));
			}
		} catch (SQLException ex) {
		    ex.printStackTrace();
		}

	}

}
